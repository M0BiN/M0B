import React from "react";
import "./gauge.style.css";
function Gauge({degree}:{degree:number}) {
  
  return (
    <div className="gauge">
      <div className="category poor">
        {" "}
        {"underweight".split("").map((e)=><span className="char">{e}</span>)}
      </div>
      <div className="category fair">
        {" "}
        {"Normal".split("").map((e)=><span className="char">{e}</span>)}

      </div>
      <div className="category good">  
      {"Overweight".split("").map((e)=><span className="char">{e}</span>)}
      </div>
      <div className="category excellent">
      {"Obese".split("").map((e)=><span className="char">{e}</span>)}

      </div>
      <div className="needle" style={{transform:`rotate(${degree}deg)` }}/>
    </div>
  );
}

export default Gauge;
