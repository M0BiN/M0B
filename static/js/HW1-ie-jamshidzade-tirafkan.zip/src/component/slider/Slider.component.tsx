import React, { Dispatch, SetStateAction } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Slider from '@material-ui/core/Slider';
import './Slider.styles.css';
const useStyles = makeStyles({
  root: {
    width: '100%',
    direction:'rtl',
    
  },
});


export default function DiscreteSlider({label,min, max, defaultValue,setState }:{label:string, min:number, max:number, defaultValue:number,setState:Dispatch<SetStateAction<number|number[]>>}) {
  const classes = useStyles();
    const handleChange = (el: any, v: number | number[])=>setState(v);
  return (
    <div className={classes.root + " SliderComponent"}>
      <Typography
        id="discrete-slider"
        style={{ fontFamily: "Fjalla One", direction: "rtl",textAlign:'left' }}
        gutterBottom
      >
        {label}
      </Typography>
      <Slider
        style={{ direction: "ltr", fontFamily: "Yekan" }}
        step={1}
        defaultValue={defaultValue}
        min={min}
        max={max}
        valueLabelDisplay="on"
        onChangeCommitted={handleChange}
      />
    </div>
  );
}