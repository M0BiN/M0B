import React from "react";
import { makeStyles, Theme, createStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemAvatar from "@material-ui/core/ListItemAvatar";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemSecondaryAction from "@material-ui/core/ListItemSecondaryAction";
import ListItemText from "@material-ui/core/ListItemText";
import Avatar from "@material-ui/core/Avatar";
import IconButton from "@material-ui/core/IconButton";
import FormGroup from "@material-ui/core/FormGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import FolderIcon from "@material-ui/icons/Folder";
import DeleteIcon from "@material-ui/icons/Delete";
import Divider from "@material-ui/core/Divider";
import Button from "@material-ui/core/Button";
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      flexGrow: 1,
      width: "100%",
      borderRadius: "24px",
    },
    demo: {
      backgroundColor: theme.palette.background.paper,
      borderRadius: "24px",
    },
    title: {
      margin: theme.spacing(4, 0, 2),
    },
  })
);

export default function InteractiveList({
  acc_suggestion,
  setAcc_suggestion,
}: {
  acc_suggestion: any;
  setAcc_suggestion: Function;
}) {
  const classes = useStyles();

  return (
    <Grid
      item
      spacing={2}
      xs={12}
      md={12}
      style={{ borderRadius: "16px", marginTop: "-25px", padding: "24px",  }}
    >
      <div className={classes.demo}>
        <List dense={true} style={{ borderRadius: "16px", backgroundColor:'rgb(247, 249, 250)', border:'1px rgb(247, 249, 250) solid' }}>
          <Typography
            style={{
              textAlign: "left",
              fontFamily: "Fjalla One",
              paddingLeft: "16px",
              margin: "8px",
            }}
            variant="h6"
          >
            Worldwide trends
          </Typography>
          {acc_suggestion.map((v, i) => (
            <>
              <Divider />
              <ListItem style={{ marginTop: "6px" }}>
                {/* <ListItemAvatar>
                  <Avatar
                    alt={v.name}
                    src={`https://i.pravatar.cc/150?u=${v.username}`}
                  >
                    <FolderIcon />
                  </Avatar>
                </ListItemAvatar> */}
                <ListItemText primary={v.name} secondary={v.username} />
                <ListItemSecondaryAction>
                  {/* <Button
                    variant="outlined"
                    color="primary"
                    onClick={()=>setAcc_suggestion((old)=>{
                      let change = old.slice();
                      change[i] = {...change[i],isFollowed:!change[i]?.isFollowed }
                      return change;
                    })}
                    style={{
                      fontWeight: 700,
                      borderRadius: "24px",
                      fontFamily: "Roboto",
                      backgroundColor: v.isFollowed ? '#1DA1F2' : "white",
                      color: v.isFollowed ? 'white' : "#1DA1F2",
                      borderColor: `#1DA1F2`,
                    }}
                  >
                    {v.isFollowed ? "Followed" : "Follow"}
                  </Button> */}
                </ListItemSecondaryAction>
              </ListItem>
            </>
          ))}
        </List>
      </div>
    </Grid>
  );
}
