import React from "react";
import { makeStyles, Theme, createStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardMedia from "@material-ui/core/CardMedia";
import CardContent from "@material-ui/core/CardContent";
import CardActions from "@material-ui/core/CardActions";
import Avatar from "@material-ui/core/Avatar";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import { red } from "@material-ui/core/colors";
import FavoriteIcon from "@material-ui/icons/Favorite";
import ShareIcon from "@material-ui/icons/Share";
import MoreHorizIcon from "@material-ui/icons/MoreHoriz";
import RepeatIcon from "@material-ui/icons/Repeat";
import FavoriteBorderIcon from "@material-ui/icons/FavoriteBorder";
import ChatBubbleOutlineIcon from "@material-ui/icons/ChatBubbleOutline";
import MenuItem from "@material-ui/core/MenuItem";
import Grow from "@material-ui/core/Grow";
import Paper from "@material-ui/core/Paper";
import Popper from "@material-ui/core/Popper";
import ClickAwayListener from "@material-ui/core/ClickAwayListener";
import MenuList from "@material-ui/core/MenuList";
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert, { AlertProps } from '@material-ui/lab/Alert';
import "./tweetCard.style.css";
type tweetType = {
  name: string;
  text: string;
  image: string;
  isLiked: boolean;
  isRetweeted: boolean;
  username: string;
  index: number;
  totalLike: string;
  totalRetweet: string;
  setChange: Function;
  isReplyed?: boolean;
  replyedTweet?: number;
  replys?: any[];
};
function Alert(props: AlertProps) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}
const isInt = (value: any) => {
  var er = /^-?[0-9]+$/;
  return er.test(value);
};
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      //   maxWidth: 345,
      border: "1px #e3e3e3 solid",
      borderTop: "1px #e3e3e3 solid",
      borderLeft: "1px #e3e3e3 solid",
      borderRight: "1px #e3e3e3 solid",
      borderRadius: "0",
      cursor: "pointer",
    },
    media: {
      borderRadius: "16px",
      height: 0,
      paddingTop: "56.25%", // 16:9
    },
    expand: {
      transform: "rotate(0deg)",
      marginLeft: "auto",
      transition: theme.transitions.create("transform", {
        duration: theme.transitions.duration.shortest,
      }),
    },
    expandOpen: {
      transform: "rotate(180deg)",
    },
    avatar: {
      backgroundColor: red[500],
    },
  })
);

export default function RecipeReviewCard({
  tweet,
  noBorder = true,
  setReplyTweet = null,
  setDialogOpen = null,
  setFocusedTweet = null,
}: {
  tweet: tweetType;
  noBorder?: boolean;
  setReplyTweet?: Function | null;
  setDialogOpen?: Function | null;
  setFocusedTweet?: Function | null;
}) {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const [shareOpen, setShareOpen] = React.useState(false);
  const handleAlertClose = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }

    setShareOpen(false);
  };
  // const [myAvatar, setAvatar] = React.useState(``);
  // React.useEffect(()=>{
  //   const avatar = fetch(`https://cors-anywhere.herokuapp.com/https://i.pravatar.cc/150`).then((e)=>console.log(e));
  // },[])
  const anchorRef = React.useRef(null);

  const handleToggle = () => {
    setOpen((prevOpen) => !prevOpen);
  };

  const handleClose = (event) => {
    if (anchorRef.current && anchorRef.current.contains(event.target)) {
      return;
    }

    setOpen(false);
  };

  function handleListKeyDown(event) {
    if (event.key === "Tab") {
      event.preventDefault();
      setOpen(false);
    }
  }

  // return focus to the button when we transitioned from !open -> open
  const prevOpen = React.useRef(open);
  React.useEffect(() => {
    if (prevOpen.current === true && open === false) {
      anchorRef?.current?.focus();
    }

    prevOpen.current = open;
  }, [open]);

  return (
    <Card
      className={classes.root}
      key={tweet.name + "" + tweet.index}
      style={
        noBorder
          ? { boxShadow: "none", borderTop: "0" }
          : { border: "0", boxShadow: "none" }
      }
    >
      <CardHeader
        avatar={
          <Avatar aria-label="recipe" className={classes.avatar} src={tweet.name==="M0B"? `https://i.pravatar.cc/150?img=70` : `https://i.pravatar.cc/150?u=${tweet.username}`}>
            {tweet.name?.charAt(0) || ""}
          </Avatar>
        }
        action={
          tweet.username === "@M0B_iN" && noBorder ? (
            <>
              <IconButton
                ref={anchorRef}
                aria-controls={open ? "menu-list-grow" : undefined}
                aria-haspopup="true"
                onClick={handleToggle}
              >
                <MoreHorizIcon />
              </IconButton>

              <Popper
                open={open}
                anchorEl={anchorRef.current}
                role={undefined}
                transition
                disablePortal
              >
                {({ TransitionProps, placement }) => (
                  <Grow
                    {...TransitionProps}
                    style={{
                      transformOrigin:
                        placement === "bottom" ? "center top" : "center bottom",
                    }}
                  >
                    <Paper style={{ marginRight: "20px" }}>
                      <ClickAwayListener onClickAway={handleClose}>
                        <MenuList
                          autoFocusItem={open}
                          id="menu-list-grow"
                          onKeyDown={handleListKeyDown}
                        >
                          <MenuItem
                            onClick={(e) => {
                              tweet.setChange((old) =>
                                old.filter((_, i: number) => i !== tweet.index)
                              );
                              handleClose(e);
                            }}
                          >
                            Delete
                          </MenuItem>
                        </MenuList>
                      </ClickAwayListener>
                    </Paper>
                  </Grow>
                )}
              </Popper>
            </>
          ) : null
        }
        style={{ textAlign: "left" }}
        title={tweet.name}
        subheader={tweet.username}
      />
      <div style={{ paddingLeft: "10%", paddingRight: "3%" }}>
        <CardContent
          onClick={() =>
            setFocusedTweet && !tweet.isReplyed && setFocusedTweet(tweet.index)
          }
          style={{ width: "500px" }}
        >
          <Typography
            align="left"
            variant="body2"
            color="textSecondary"
            component="p"
          >
            {tweet.text}
          </Typography>
        </CardContent>
        {tweet?.image ? (
          <CardMedia
            onClick={() =>
              setFocusedTweet &&
              !tweet.isReplyed &&
              setFocusedTweet(tweet.index)
            }
            className={classes.media}
            image={tweet.image}
            // src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Jaguar.jpg/1200px-Jaguar.jpg"
            title={`${tweet.name}'s Photo`}
          />
        ) : null}
      </div>
      {noBorder ? (
        <CardActions
          style={{ justifyContent: "space-around", cursor: "default" }}
        >
          <IconButton
          style={tweet.isReplyed ? {opacity:'0.6'} : null}
          disabled={tweet.isReplyed}
            onClick={() => {
              setReplyTweet(
                tweet?.isReplyed ? tweet.replyedTweet : tweet.index
              );
              setDialogOpen(true);
            }}
          >
            <ChatBubbleOutlineIcon />
            <Typography
              align="left"
              variant="caption"
              style={{
                fontFamily: "Roboto",
                cursor: "default",
                position: "absolute",
                marginLeft: "30px",
                fontWeight: 700,
              }}
            >
              {tweet?.replys?.length ? tweet?.replys?.length : 0}
            </Typography>
          </IconButton>
          <IconButton
            onClick={() =>
              tweet.setChange((o: any) => {
                if (tweet.isReplyed) {
                  let changes = o.slice();
                  let sub_changes = changes[tweet.replyedTweet].replys.slice();
                  sub_changes[tweet.index] = {
                    ...sub_changes[tweet.index],
                    isRetweeted: !sub_changes[tweet.index].isRetweeted,
                  };
                  changes[tweet.replyedTweet] = {
                    ...changes[tweet.replyedTweet],
                    replys: sub_changes,
                  };
                  return changes;
                }
                let changes = o.slice();
                changes[tweet.index] = {
                  ...changes[tweet.index],
                  isRetweeted: !changes[tweet.index].isRetweeted,
                };
                return changes;
              })
            }
          >
            <RepeatIcon style={{ color: tweet.isRetweeted ? `#17BF63` : `` }} />
            <Typography
              align="left"
              variant="caption"
              style={{
                fontFamily: "Roboto",
                cursor: "default",
                position: "absolute",
                marginLeft: "30px",
                fontWeight: 700,
                color: tweet.isRetweeted ? "#17BF63" : "",
              }}
            >
              {isInt(tweet.totalRetweet) && tweet.isRetweeted
                ? parseInt(tweet.totalRetweet) + 1
                : tweet.totalRetweet}
            </Typography>
          </IconButton>

          <IconButton
            onClick={() =>
              tweet.setChange((o: any) => {
                if (tweet.isReplyed) {
                  let changes = o.slice();
                  let sub_changes = changes[tweet.replyedTweet].replys.slice();
                  sub_changes[tweet.index] = {
                    ...sub_changes[tweet.index],
                    isLiked: !sub_changes[tweet.index].isLiked,
                  };
                  changes[tweet.replyedTweet] = {
                    ...changes[tweet.replyedTweet],
                    replys: sub_changes,
                  };
                  return changes;
                }
                let changes = o.slice();
                changes[tweet.index] = {
                  ...changes[tweet.index],
                  isLiked: !changes[tweet.index].isLiked,
                };
                return changes;
              })
            }
          >
            {tweet.isLiked ? (
              <FavoriteIcon color="secondary" />
            ) : (
              <FavoriteBorderIcon />
            )}
            <Typography
              align="left"
              variant="caption"
              color={tweet.isLiked ? "secondary" : "inherit"}
              style={{
                fontFamily: "Roboto",
                cursor: "default",
                position: "absolute",
                marginLeft: "30px",
                fontWeight: 700,
              }}
            >
              {isInt(tweet.totalLike) && tweet.isLiked
                ? parseInt(tweet.totalLike) + 1
                : tweet.totalLike}
            </Typography>
          </IconButton>
          <IconButton aria-label="share" onClick={()=>setShareOpen(true)}>
            <ShareIcon />
          </IconButton>
          {/* <IconButton
          className={clsx(classes.expand, {
            [classes.expandOpen]: expanded,
          })}
          onClick={handleExpandClick}
          aria-expanded={expanded}
          aria-label="show more"
        >
          <ExpandMoreIcon />
        </IconButton> */}
        </CardActions>
      ) : (
        <span style={{ paddingLeft: "48px" }}>
          {`Reply to`}{" "}
          <span style={{ color: "#1DA1F2" }}> {tweet.username}</span>
        </span>
      )}
      <Snackbar open={shareOpen} autoHideDuration={2000} onClose={handleAlertClose}>
        <Alert onClose={handleAlertClose} severity="info">
        Copied to clipboard
        </Alert>
      </Snackbar>
    </Card>
  );
}
