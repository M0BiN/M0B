import React from 'react';
import { withStyles, makeStyles, Theme, createStyles } from '@material-ui/core/styles';
import Slider from '@material-ui/core/Slider';
import Typography from '@material-ui/core/Typography';
import Tooltip from '@material-ui/core/Tooltip';
import IconButton from '@material-ui/core/IconButton';

import Grid from '@material-ui/core/Grid';
import RemoveIcon from '@material-ui/icons/Remove';
import AddIcon from '@material-ui/icons/Add';
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      width: 500 + theme.spacing(3) * 2,
    },
    margin: {
      height: theme.spacing(3),
    },
  }),
);

interface Props {
  children: React.ReactElement;
  open: boolean;
  value: number;
}





const PrettoSlider = withStyles({
  root: {
    color: '#52af77',
    height: 8,
  },
  thumb: {
    height: 18,
    width: 18,
    backgroundColor: '#fff',
    border: '2px solid currentColor',
    marginTop: -6,
    marginLeft: -12,
    '&:focus, &:hover, &$active': {
      boxShadow: 'inherit',
    },
  },
  active: {},
  valueLabel: {
    left: 'calc(-50% + 4px)',
  },
  track: {
    height: 6,
    borderRadius: 4,
  },
  rail: {
    height: 4,
    borderRadius: 4,
  },
})(Slider);


export default function CustomizedSlider({value, setValue,color }:{value:number, setValue:Function,color:string}) {
  const classes = useStyles();

  return (
    <div className={classes.root}>

      <div className={classes.margin} />
      <Grid container spacing={2}>
        <Grid item>
        <IconButton aria-label="delete" className={classes.margin} size="small" onClick={()=>setValue((o:number)=>o>40 ? o-1 : o)}>
        <RemoveIcon  style={{color, fontSize:'40px',fontWeight:'bolder' }} />
        </IconButton>
          
        </Grid>
        <Grid item xs>
          <PrettoSlider
            // valueLabelDisplay="auto"
            style={{color:color}}
            aria-label="pretto slider"
            defaultValue={40}
            min={40}
            max={220}
            value={value}
            onChange={(e,v)=>setValue(v)}
            onChangeCommitted={(e,v)=>setValue(v)}
          />
        </Grid>
        <Grid item>
        <IconButton aria-label="delete" className={classes.margin} size="small" onClick={()=>setValue((o:number)=>o<220 ? o+1 : o)}>
        <AddIcon  style={{color, fontSize:'40px',fontWeight:'bolder' }}  />
        </IconButton>
        </Grid>
      </Grid>


    </div>
  );
}