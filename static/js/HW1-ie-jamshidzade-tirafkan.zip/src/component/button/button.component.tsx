import React, { Dispatch, SetStateAction } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";

const useStyles = makeStyles((theme) => ({
  root: {
    "& > *": {
      //   margin: theme.spacing(1),
    },
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    alignContent: "center",
  },
  button: {
    width: "100%",
    margin: "1px",
    fontFamily:'Fjalla One'
    
  },
}));

export default function OutlinedButtons({gender, setGender}:{gender:any , setGender:Dispatch<SetStateAction<string>>}) {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <Button
        className={classes.button}
        variant="contained"
        color={gender === "male" ? "primary" : undefined}
        onClick={() => setGender("male")}
      >
        {"Male"}
      </Button>
      <Button
        className={classes.button}
        variant="contained"
        color={gender === "female" ? "primary" : undefined}
        onClick={()=>setGender("female")}
      >
        {"Female"}
      </Button>
    </div>
  );
}
