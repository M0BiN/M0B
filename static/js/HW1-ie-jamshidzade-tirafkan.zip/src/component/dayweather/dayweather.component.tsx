import React from "react";
import Typography from "@material-ui/core/Typography";
import Grid from "@material-ui/core/Grid";
import Button from "@material-ui/core/Button";
function DayWeather({icon, hour, temp}:{icon:string|undefined, hour:string|undefined, temp:number|undefined}) {
  return <Grid container xs={12} direction="column" justify="center" alignItems="center" >
      <Grid
      item
      xs={12}
      style={{fontFamily:'Oswald', color:'#424242'}}
      >
          {hour || ''}
      </Grid>
      <Grid
      item
      xs={12}
      
      >
          <img style={{ width:'100%'}} src={icon}  />
      </Grid>
      <Grid
      item
      xs={12}
      
      
      >
          <Typography variant="h6" style={{fontFamily:'Oswald', color:'#424242'}}>
          {`${temp}`}
          <Typography variant="caption" style={{fontFamily:'Oswald', color:'#424242', verticalAlign:'top'}}>
          °C
          </Typography>
          </Typography>
          
         
      </Grid>


  </Grid>;
}

export default DayWeather;
