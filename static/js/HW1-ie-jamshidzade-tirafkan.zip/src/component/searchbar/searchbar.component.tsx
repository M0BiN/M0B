import React from 'react';
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import InputBase from '@material-ui/core/InputBase';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import SearchIcon from '@material-ui/icons/Search';
import DirectionsIcon from '@material-ui/icons/Directions';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      padding: '2px 4px',
      display: 'flex',
      alignItems: 'center',
      width: 400,
      borderRadius:'24px',
      marginTop:'8px',
      marginLeft:'24px',
      boxShadow:'none',
      backgroundColor:'rgb(247, 249, 250)',
      border:'1px rgb(247, 249, 250) solid'
    },
    input: {
      marginLeft: theme.spacing(1),
      flex: 1,
      fontFamily:'Roboto',
      
    },
    iconButton: {
      padding: 10,
    },
    divider: {
      height: 28,
      margin: 4,
    },
  }),
);

export default function CustomizedInputBase() {
  const classes = useStyles();

  return (
    <Paper component="form" className={classes.root}>
      {/* <IconButton className={classes.iconButton} aria-label="menu">
        <MenuIcon />
      </IconButton> */}
       <IconButton  className={classes.iconButton} aria-label="search" >
        <SearchIcon />
      </IconButton>
      <InputBase
        className={classes.input}
        placeholder="Search Twitter"
        inputProps={{ 'aria-label': 'search google maps' }}
      />
     
      {/* <Divider className={classes.divider} orientation="vertical" />
      <IconButton color="primary" className={classes.iconButton} aria-label="directions">
        <DirectionsIcon />
      </IconButton> */}
    </Paper>
  );
}
