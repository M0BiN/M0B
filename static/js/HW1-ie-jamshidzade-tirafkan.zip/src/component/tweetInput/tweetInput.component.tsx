import React from "react";
import { makeStyles, Theme, createStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardMedia from "@material-ui/core/CardMedia";
import CardContent from "@material-ui/core/CardContent";
import CardActions from "@material-ui/core/CardActions";
import Avatar from "@material-ui/core/Avatar";
import IconButton from "@material-ui/core/IconButton";
import { red } from "@material-ui/core/colors";
import GifOutlinedIcon from "@material-ui/icons/GifOutlined";
import PanoramaOutlinedIcon from "@material-ui/icons/PanoramaOutlined";
import "./tweetInput.style.css";
import Button from "@material-ui/core/Button";
import HighlightOffIcon from "@material-ui/icons/HighlightOff";
import Divider from "@material-ui/core/Divider";

export default function RecipeReviewCard({
  setChange,
  type="",
  index=0,
  setOpen
}: {
  setChange: Function;
  type?:string;
  index?:number;
  setOpen?:Function
}) {
  const classes = useStyles();
  const [tweet, setTweet] = React.useState({ text: "", image: "" });
  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) =>
    setTweet((old) => ({ ...old, [e.target.name]: e.target.value.replace(/(#\S+)/, '<span style="color: blue">$1</span>')}));
  const handleChangeFile = (e: React.ChangeEvent<HTMLInputElement>) =>
    setTweet((old) => ({
      ...old,
      [e.target.name]: e.target?.files?.[0]
        ? URL.createObjectURL(e.target.files[0])
        : ``,
    }));
  return (
    <Card className={classes.root} style={{border:type ? '0' : '', boxShadow: 'none', borderTop:'0'}}>
      <CardHeader
        avatar={
          <Avatar aria-label="recipe" className={classes.avatar} alt={"M0B"} src={`https://i.pravatar.cc/150?img=70`}>
            M
          </Avatar>
        }
        children={<div>"sss"</div>}
        style={{ textAlign: "left" }}
        title=""
        subheader=""
      />

      <div
        style={{ paddingLeft: "10%", paddingRight: "3%", marginTop: "-60px" }}
      >
        <CardContent>
          <textarea
            className="textAreaTweet"
            defaultValue=""
            placeholder={type ? "Tweet your reply" : "What's happening?"}
            value={tweet.text}
            name="text"
            onChange={handleChange}
            autoFocus={true}
          >
                      <div>
            sss
          </div>
          
            </textarea>
            
        </CardContent>
        {tweet?.image ? (
          <CardMedia
            className={classes.media}
            image={tweet.image}
            // src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Jaguar.jpg/1200px-Jaguar.jpg"
            title="Photo"
            style={{display:'flex', justifyContent:'center', cursor:'pointer'}}
          >
            <IconButton onClick={() => setTweet((o) => ({ ...o, image: `` }))} >
              <HighlightOffIcon style={{ color: "#1DA1F2"}} />
            </IconButton>
          </CardMedia>
        ) : null}

      </div>
      
      <CardActions
        style={{
          justifyContent: "space-between",
          cursor: "default",
          paddingLeft: "44px",
          marginTop: tweet?.image ? "" : "-46px",
        }}
      >
        
        <div style={{ display: "flex", justifyContent: "flex-start" }}>
       
          <input
            style={{ display: "none" }}
            name="image"
            accept="image/*"
            id={"icon-button-file" + type}
            type="file"
            onChange={handleChangeFile}

          />
          <label htmlFor={"icon-button-file" + type}>
            <IconButton aria-label="add to favorites" component="span">
              <PanoramaOutlinedIcon style={{ color: `#1DA1F2` }} />
            </IconButton>
          </label>
          <label htmlFor={"icon-button-file" + type}>
            <IconButton aria-label="add to favorites" component="span">
              <GifOutlinedIcon style={{ color: `#1DA1F2` }} />
            </IconButton>
          </label>
        </div>
        <Button
          variant="outlined"
          style={{
            fontWeight: 700,
            borderRadius: "24px",
            color: "white",
            borderColor: `white`,
            backgroundColor: `#1DA1F2`,
            marginRight: "14px",
            opacity: tweet?.text?.length ? "1" : "0.4",
          }}
          disabled={tweet?.text?.length ? false : true}
          onClick={() => {
            
            if(type){
              setChange((old)=>{
                let myTweets = old.slice();
                let tweet_replays = myTweets[index].replys.slice();
                tweet_replays.push({
                  text: tweet.text,
                  image: tweet.image,
                  name: `M0B`,
                  username: `@M0B_iN`,
                  isLiked: false,
                  isRetweeted: false,
                  totalLike: `0`,
                  totalRetweet: `0`,
                  replyedTweet:index,
                  isReplyed:true,
                  replys:[],
                  
                });
                myTweets[index].replys = tweet_replays;
                return myTweets;
              })
              setTweet({ text: "", image: "" });
              if(setOpen) setOpen(false);
              return;
            }
            setChange((old) => {
              let myTweets = old.slice();
              myTweets.unshift({
                text: tweet.text,
                image: tweet.image,
                name: `M0B`,
                username: `@M0B_iN`,
                isLiked: false,
                isRetweeted: false,
                totalLike: `0`,
                totalRetweet: `0`,
                replys:[]
              });
              return myTweets;
            });
            setTweet({ text: "", image: "" });
            if(setOpen) setOpen(false);
            
          }}
        >
          {type ? `Reply` : `Tweet`}
        </Button>
      </CardActions>
    </Card>
  );
}

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      //   maxWidth: 345,
      border: "1px #e3e3e3 solid",
      borderTop: "1px #e3e3e3 solid",
      borderLeft: "1px #e3e3e3 solid",
      borderRight: "1px #e3e3e3 solid",
      borderRadius: "0",
      cursor: "pointer",
    },
    media: {
      borderRadius: "16px",
      height: 0,
      paddingTop: "56.25%", // 16:9
    },
    expand: {
      transform: "rotate(0deg)",
      marginLeft: "auto",
      transition: theme.transitions.create("transform", {
        duration: theme.transitions.duration.shortest,
      }),
    },
    expandOpen: {
      transform: "rotate(180deg)",
    },
    avatar: {
      backgroundColor: red[500],
    },
  })
);
