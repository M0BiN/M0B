import React from "react";

import "./input.style.css";
function Input({number,setNumber,base, isSpecial}: {
  number: string;
  setNumber: Function;
  base: number;
  isSpecial?:boolean
}) {
  const postfix = ()=>{
    const match = /\.0*$/.exec(number);
    const matchEndZerosAfterDecimal = /\.0*[^0]+(0*)$/.exec(number);

    return parseFloat(number).toString(base) + (match?.[0] ? match[0] : '') + (matchEndZerosAfterDecimal?.[1] || '');
    
  }
  return (
    <div className="form__field">
      <label htmlFor="login__username" style={{ backgroundColor: !isSpecial ? `#2979ff`: `#b71c1c`, width:'28%' }}>
        <p style={{fontFamily:'Roboto', width:'50px'}}>{`Base ${base}`}</p>
        <span className="hidden">{`Base ${base}`}</span>
      </label>
      <input
        key={`inputBase${base}`}
        type="text"
    
        value={postfix()}
        onChange={(e) =>{
          if(regexs[base-2].test(e.target.value)){
            const match = /\.0*$/.exec(e.target.value);
            const num = FloatParser(e.target.value.toLowerCase(), base);
            const matchEndZerosAfterDecimal = /\.0*[^0]+(0*)$/.exec(e.target.value);
            setNumber((num && match?.[0]  ? num + "" + match[0] : num ? num : "0") + "" + (matchEndZerosAfterDecimal?.[1] || ''));
          }
          
        }
          
        }
        className="form__input"
        placeholder={`Base ${base}`}
        autoComplete="off"
      />
    </div>
  );
}

export default Input;

const FloatParser = (str: string = "", radix: number) => {
  // Split the string at the decimal point
  let string: any = str.split(/\./);

  // If there is nothing before the decimal point, make it 0
  if (string[0] == "") {
    string[0] = "0";
  }

  // If there was a decimal point & something after it
  if (string.length > 1 && string[1] != "") {
    var fractionLength = string[1].length;
    string[1] = parseInt(string[1], radix);
    string[1] *= Math.pow(radix, -fractionLength);
    return parseInt(string[0], radix) + string[1];
  }

  // If there wasn't a decimal point or there was but nothing was after it
  return parseInt(string[0], radix) ;
};
const regexs = [
  /^([0-1]*|[0-1]*\.[0-1]*)$/,
  /^([0-2]*|[0-2]*\.[0-2]*)$/,
  /^([0-3]*|[0-3]*\.[0-3]*)$/,
  /^([0-4]*|[0-4]*\.[0-4]*)$/,
  /^([0-5]*|[0-5]*\.[0-5]*)$/,
  /^([0-6]*|[0-6]*\.[0-6]*)$/,
  /^([0-7]*|[0-7]*\.[0-7]*)$/,
  /^([0-8]*|[0-8]*\.[0-8]*)$/,
  /^([0-9]*|[0-9]*\.[0-9]*)$/,
  /^([0-9a]*|[0-9a]*\.[0-9a]*)$/,
  /^([0-9ab]*|[0-9ab]*\.[0-9ab]*)$/,
  /^([0-9a-c]*|[0-9a-c]*\.[0-9a-c]*)$/,
  /^([0-9a-d]*|[0-9a-d]*\.[0-9a-d]*)$/,
  /^([0-9a-e]*|[0-9a-e]*\.[0-9a-e]*)$/,
  /^([0-9a-f]*|[0-9a-f]*\.[0-9a-f]*)$/,
];
