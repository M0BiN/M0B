import React from "react";
import Typography from "@material-ui/core/Typography";
import Grid from "@material-ui/core/Grid";
function DayWeather({wind_speed, wind_dir, hour}:{ wind_speed:number|undefined, wind_dir:string|undefined, hour:string|undefined}) {
  return <Grid container xs={12} direction="column" justify="center" alignItems="center" >
      <Grid
      item
      xs={12}
      
      >
          <Typography variant="caption" style={{fontFamily:'Oswald', color:'#424242'}}>
          {`${wind_speed} km/h`}
          
          </Typography>
          
      </Grid>
      <Grid
      item
      xs={12}
      
      >
          <img style={{ width:'100%',transform:`rotate(${-90 + getDirection(wind_dir)}deg)`, transition:`400ms linear`,
           filter:"invert(31%) sepia(25%) saturate(1775%) hue-rotate(127deg) brightness(95%) contrast(102%)"}}
           src={`https://ssl.gstatic.com/m/images/weather/wind_unselected.svg`}  />
      </Grid>
      <Grid
      item
      xs={12}
      
      
      >
          <Typography variant="caption" style={{fontFamily:'Oswald', color:'#424242'}}>
          {hour}
          
          </Typography>
          
         
      </Grid>


  </Grid>;
}

export default DayWeather;



const getDirection = (wind_dir:string):number =>{
    const obj = {
        'N':348.75,
        'NNE':11.25,
        'NE':33.75,
        'ENE':56.25,
        'E':78.75,
        'ESE':101.25,
        'SE':123.75,
        'SSE':146.25,
        'S':168.75,
        'SSW':191.25,
        'SW':213.75,
        'WSW':236.25,
        'W':258.75,
        'WNW':281.25,
        'NW':303.75,
        'NNW':326.25
    }
    return obj[wind_dir] || 0;
}

