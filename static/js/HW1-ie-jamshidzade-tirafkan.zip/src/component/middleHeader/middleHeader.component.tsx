import React from "react";
import "./middleHeader.style.css";
import IconButton from '@material-ui/core/IconButton';

import Divider from "@material-ui/core/Divider";
import GradeOutlinedIcon from "@material-ui/icons/GradeOutlined";
import Typography from "@material-ui/core/Typography";
import ArrowBackIcon from "@material-ui/icons/ArrowBack";
function MiddleHeader({ focusedTweet, setFocusedTweet }: { focusedTweet: number | null; setFocusedTweet:Function }) {
  return (
    <>
      <div
        style={{
          display: "flex",
          justifyContent: focusedTweet === null ? "space-between" : "flex-start",
          alignItems: "center",
          padding: focusedTweet === null ? "10px" : "0",
          paddingRight: "35px",
          paddingLeft: "15px",
          borderLeft: "1px #e3e3e3 solid",
          borderRight: "1px #e3e3e3 solid",
          borderBottom: "0",
          boxShadow:  'none'
        }}
      >
        {focusedTweet !== null ?<IconButton
        onClick={()=>setFocusedTweet(null)}
        ><ArrowBackIcon style={{ color: "#1DA1F2" }} /> </IconButton>: null}
        <Typography
          variant="h6"
          style={{ fontFamily: "Roboto", fontWeight: 900 }}
        >
          {focusedTweet === null ? "Home" : "Tweet"}
        </Typography>
        {focusedTweet === null ? (
          <GradeOutlinedIcon style={{ color: "#1DA1F2" }} />
        ) : (
          null
        )}
      </div>
      <Divider />
    </>
  );
}

export default MiddleHeader;
