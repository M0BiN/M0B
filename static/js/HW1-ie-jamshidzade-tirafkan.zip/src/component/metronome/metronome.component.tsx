import React from 'react'
import './metronome.style.css';
function Metronome() {
    return (
        <div className="box">
        <div className="stick">
          <div className="stick-inner" />
          <label htmlFor="play" className="block" />
        </div>
        <div className="timer">
          <div>60</div>
          <div>80</div>
          <div>100</div>
          <div>120</div>
          <div>140</div>
          <div>160</div>
          <div>180</div>
        </div>
        <div className="base">
        </div>
      </div>
    )
}

export default Metronome;
