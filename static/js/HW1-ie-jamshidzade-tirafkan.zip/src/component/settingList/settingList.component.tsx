import React from 'react';
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import HomeOutlinedIcon from '@material-ui/icons/HomeOutlined';
import ExploreOutlinedIcon from '@material-ui/icons/ExploreOutlined';
import MailOutlineIcon from '@material-ui/icons/MailOutline';
import BookmarkBorderIcon from '@material-ui/icons/BookmarkBorder';
import ListAltOutlinedIcon from '@material-ui/icons/ListAltOutlined';
import PersonOutlineOutlinedIcon from '@material-ui/icons/PersonOutlineOutlined';
import MoreHorizIcon from '@material-ui/icons/MoreHoriz';
import TwitterIcon from '@material-ui/icons/Twitter';
import IconButton from '@material-ui/core/IconButton';
import NotificationsNoneIcon from '@material-ui/icons/NotificationsNone';
import Button from '@material-ui/core/Button';

const icons = [{title:'Home', icon:HomeOutlinedIcon}, {title:'Explore', icon:ExploreOutlinedIcon},
                {title:'Notifications', icon:NotificationsNoneIcon},
                {title:'Messages', icon:MailOutlineIcon},
                {title:'Bookmarks', icon:BookmarkBorderIcon},
                {title:'Lists', icon:BookmarkBorderIcon},
                {title:'Profile', icon:PersonOutlineOutlinedIcon},
                {title:'More', icon:MoreHorizIcon},
]
// const icons = [HomeOutlinedIcon, ExploreOutlinedIcon, MailOutlineIcon, BookmarkBorderIcon, ListAltOutlinedIcon, PersonOutlineOutlinedIcon, MoreHorizIcon];
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      width: '100%',

    //   maxWidth: 360,
      backgroundColor: theme.palette.background.paper,
      display:'flex',
      flexDirection:'column',
      justifyContent:'center',
      alignItems:'flex-end'

    },
    nested: {
      paddingLeft: theme.spacing(4),
    },
  }),
);

export default function NestedList() {
  const classes = useStyles();

  return (
    <List
      component="nav"
      aria-labelledby="nested-list-subheader"
    //   subheader={
    //     <ListSubheader component="div" id="nested-list-subheader">
    //       Nested List Items
    //     </ListSubheader>
    //   }
      className={classes.root}
    >

<div style={{marginRight:'72px'}}>
<IconButton style={{marginRight:'116px'}}>
        <TwitterIcon style={{color:'#1DA1F2', fontSize:'36px'}} />

        </IconButton>

        {icons.map((e)=>
              (<ListItem button style={{maxWidth:'fit-content', borderRadius:'24px', position:'relative', right:'0', marginTop:'8px'}}>
              <ListItemIcon>
                <e.icon />
              </ListItemIcon>
              <ListItemText primary={e.title} style={{fontSize:'54px'}} />
            </ListItem>)
        )}
        <Button variant="outlined" color="primary"
         style={{width:'100%' ,backgroundColor:'#1DA1F2',
          fontWeight:700, borderRadius:'24px', fontFamily:'Roboto',
           color:'snow', borderColor:`#1DA1F2`, height:'48px',
           marginTop:'8px'
           }}>
                    Tweet
                  </Button>
</div>

    </List>
  );
}