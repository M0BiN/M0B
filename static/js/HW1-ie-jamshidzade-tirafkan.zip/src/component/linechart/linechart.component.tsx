import React from 'react'
import {Line} from 'react-chartjs-2';
import ChartDataLabels from 'chartjs-plugin-datalabels';

function LineChart({data, label}:{data:number[]|undefined, label:string[]|undefined}) {
    return (
        <div style={{paddingTop:'20px'}}>
        <Line data={getData(data, label)} options={{...option,layout:{padding:{left:40, right:40, top:30}}, plugins:{datalabels:{align:'end', font:{weight:'bolder'}}}}} />
      </div>
    )
}

export default LineChart;



const option = {
    legend: {
        display: false
     },
        maintainAspectRatio: false,
        scales: {
            yAxes: [{
                ticks: {
                    display: false,
                    beginAtZero: true,
                    

                },
                gridLines: {
                    display:false
                }
            }],
            xAxes: [{
                gridLines: {
                  display: false
                },
                ticks: {
                  beginAtZero: true,
                  
                },
                
              }],
              
        },
 
          
          plugins:{...ChartDataLabels,
            datalabels: {
              color: 'red',
                        
              

            },
            layout: {
              padding: {
                  left: 100,
                  right: 0,
                  top: 0,
                  bottom: 0
              }
          }
            
            

}
}
const getData = (data:number[], labels:string[])=>({
  
  labels: labels,
  datasets: [
    {
      label: '',
      fill: true,
      lineTension: 0.1,
      backgroundColor: 'rgba(255, 245, 157, 0.7)',
      borderColor: '#ffee33',
      borderDash: [],
      borderDashOffset: 0.0,
      pointBorderColor: '#ffa000',
      pointBackgroundColor: '#fff',
      pointBorderWidth: 6,
      pointHoverRadius: 5,
      pointHoverBackgroundColor: 'rgba(75,192,192,1)',
      pointHoverBorderColor: 'rgba(220,220,220,1)',
      pointHoverBorderWidth: 2,
      pointRadius: 1,
      scaleShowLabels: true,
      pointHitRadius: 10,
      data: data
      
     

    },
    
    
  ],


}) ;
