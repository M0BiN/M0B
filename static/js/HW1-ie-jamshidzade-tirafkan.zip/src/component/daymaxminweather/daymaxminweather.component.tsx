import React from "react";
import Typography from "@material-ui/core/Typography";
import Grid from "@material-ui/core/Grid";
import Button from "@material-ui/core/Button";
function DayWeather({
  icon,
  hour,
  max_temp,
  min_temp,
}: {
  icon: string | undefined;
  hour: string | undefined;
  max_temp: number | undefined;
  min_temp: number | undefined;
}) {
  return (
    <Grid
      container
      xs={12}
      direction="column"
      justify="center"
      alignItems="center"
    >
      <Grid item xs={12} style={{ fontFamily: "Oswald", color: "#424242" }}>
        {hour || ""}
      </Grid>
      <Grid item xs={12}>
        <img style={{ width: "100%" }} src={icon} />
      </Grid>
      <Grid item container xs={12} justify="center" direction="row">
        <Grid item>
          <Typography
            variant="h6"
            style={{ fontFamily: "Oswald", color: "#424242", fontSize: "14px" }}
          >
            {`${max_temp}`}
            <Typography
              variant="caption"
              style={{
                fontFamily: "Oswald",
                color: "#424242",
                verticalAlign: "top",
                fontSize: "8px",
              }}
            >
              °C
            </Typography>
          </Typography>
          <Grid item>

          </Grid>
        </Grid>
        <Grid item style={{marginLeft:'8px'}}>
          <Typography
            variant="h6"
            style={{ fontFamily: "Oswald", color: "#9e9e9e", fontSize: "14px" }}
          >
            {`${min_temp}`}
            <Typography
              variant="caption"
              style={{
                fontFamily: "Oswald",
                color: "#9e9e9e",
                verticalAlign: "top",
                fontSize: "8px",
              }}
            >
              °C
            </Typography>
          </Typography>
        </Grid>
      </Grid>
    </Grid>
  );
}

export default DayWeather;
