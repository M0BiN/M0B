import React from 'react'
import ChartDataLabels from 'chartjs-plugin-datalabels';

import {Bar} from 'react-chartjs-2';
function Barchart({data, label}:{data:number[]|undefined, label:string[]|undefined}) {
    return (
        <div>
        <Bar
         data={getData(data, label)} 

          options={{
            maintainAspectRatio: false,
            ...option,
            plugins:{datalabels:{align:'end', font:{weight:'bolder'}}}
          }}
        />
      </div>
    )
}

export default Barchart;


const getData = (data:number[], labels:string[])=> ({
  labels: labels,
  datasets: [
    {
      backgroundColor: '#bbdefb',
      borderColor: '#2196f3',
      borderWidth: 1,
      hoverBackgroundColor: '#2196f3',
      hoverBorderColor: '#1a237e',
      data: data
    }
  ]
});


const option = {
    legend: {
        display: false
     },
        maintainAspectRatio: false,
        scales: {
            yAxes: [{
                ticks: {
                    display: false,
                    beginAtZero: true,
                    

                },
                gridLines: {
                    display:false
                }
            }],
            xAxes: [{
                gridLines: {
                  display: false
                },
                ticks: {
                  beginAtZero: true,
                  
                },
                
              }],
              
        },
 
          
          plugins:{...ChartDataLabels,
            datalabels: {
              color: 'black',
                        
              

            },
            layout: {
              padding: {
                  left: 100,
                  right: 0,
                  top: 0,
                  bottom: 0
              }
          }
            
            

}
}