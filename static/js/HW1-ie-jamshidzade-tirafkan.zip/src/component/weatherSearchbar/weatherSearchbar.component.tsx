import React from "react";
import { makeStyles, Theme, createStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import InputBase from "@material-ui/core/InputBase";
import IconButton from "@material-ui/core/IconButton";
import SearchIcon from "@material-ui/icons/Search";

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      padding: "2px 4px",
      display: "flex",
      alignItems: "center",
      borderRadius: "24px",
      marginTop: "8px",
      marginLeft: "24px",
      boxShadow: "none",
      backgroundColor: "rgb(247, 249, 250)",
      border: "1px rgb(247, 249, 250) solid",
    },
    input: {
      marginLeft: theme.spacing(1),
      flex: 1,
      fontFamily: "Roboto",
    },
    iconButton: {
      padding: 10,
    },
    divider: {
      height: 28,
      margin: 4,
    },
  })
);

export default function CustomizedInputBase({setCity, cityText="", wide=false}:{setCity:Function, cityText?:string, wide?:boolean}) {
  const classes = useStyles();
  const [text, setText] = React.useState(cityText);

  return (
    <Paper className={classes.root} style={wide ? {width:'400px'}: null}>
      {/* <IconButton className={classes.iconButton} aria-label="menu">
        <MenuIcon />
      </IconButton> */}
      <IconButton className={classes.iconButton} aria-label="search" onClick={()=>text && setCity(text)}>
        <SearchIcon />
      </IconButton>
      <InputBase
        autoFocus
        className={classes.input}
        placeholder="City Search"
        style={{ color: "#424242" }}
        inputProps={{ "aria-label": "search google maps" }}
        onKeyDown={(e)=>e.key === 'Enter' && text && setCity(text)}
        value={text}
        onChange={(e)=>setText(e.target.value)}
        
      />

      {/* <Divider className={classes.divider} orientation="vertical" />
      <IconButton color="primary" className={classes.iconButton} aria-label="directions">
        <DirectionsIcon />
      </IconButton> */}
    </Paper>
  );
}
