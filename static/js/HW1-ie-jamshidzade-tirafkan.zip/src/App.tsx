import React from 'react';
import HW1 from './pages/hw1/hw1.page';
import HW2 from './pages/hw2/hw2.page';
import HW7 from './pages/hw7/hw7.page';
import HW5 from './pages/hw5/hw5.page';
import HW6 from './pages/hw6/hw6.page';
import HW4 from './pages/hw4/hw4.page';
import HW3 from './pages/hw3/hw3.page';
import HomePage from './pages/homepage/homepage.component';
import { Route, Switch, Redirect } from "react-router-dom";
import './App.css';

function App() {
  return (
    <div className="App">
      <Switch>
      <Route exact path="/HW1" component={HW1} />
      <Route exact path="/HW2" component={HW2} />
      <Route exact path="/HW3" component={HW3} />
      <Route exact path="/HW4" component={HW4} />
      <Route exact path="/HW5" component={HW5} />
      <Route exact path="/HW6" component={HW6} />
      <Route exact path="/HW7" component={HW7} />
      <Route  path="/" component={HomePage} />
      </Switch>
      
    
    
    
    
    
    
    </div>
  );
}

export default App;
