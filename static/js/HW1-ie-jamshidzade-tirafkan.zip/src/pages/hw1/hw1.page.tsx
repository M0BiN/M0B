import React from 'react';
import './hw1.style.css';
import Gauge from '../../component/gauge/gauge.component';
import Slider from '../../component/slider/Slider.component';
import Button from '@material-ui/core/Button';
import Buttons from '../../component/button/button.component';
import Typography from '@material-ui/core/Typography';
import EjectIcon from '@material-ui/icons/Eject';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert, { AlertProps } from '@material-ui/lab/Alert';
// import CountUp from 'react-countup';
import { useCountUp } from 'react-countup';
function Alert(props: AlertProps) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}
function HW1() {
    const [gender, setGender] = React.useState('');
    const [bmi, setBMI] = React.useState(0.00);
    const [weight, setWeight] = React.useState<number|number[]>(70);
    const [height, setHeight] = React.useState<number|number[]>(175);
    const [done, setDone] = React.useState(false);
    const [degree, setDegree] = React.useState(-85);

    const [open, setOpen] = React.useState(false);
    const handleClose = (event?: React.SyntheticEvent, reason?: string) => {
      if (reason === 'clickaway') {
        return;
      }
  
      setOpen(false);
    };
    const handleClick = () => {
      setOpen(true);
    };


    const { countUp, start, pauseResume, reset, update } = useCountUp({
      start: bmi,
      end: bmi,
      delay: 1,
      duration: 1,
      decimals:2,
      // onReset: () => console.log('Resetted!'),
      // onUpdate: () => console.log('Updated!'),
      // onPauseResume: () => console.log('Paused or resumed!'),
      // onStart: ({ pauseResume }) => console.log(pauseResume),
      onEnd: ({ pauseResume }) => {
        setDone(true);
        setTimeout(()=>{setDone(false)},1000)
      },
    });
    // console.log(mapping(bmi, 7, 98, -90, 90))
    return (
      <div className="gauge-container">
        <Gauge degree={done ? mapping(bmi, ranges[input(bmi)][0], ranges[input(bmi)][1], ranges[input(bmi)][2], ranges[input(bmi)][3]) :degree} />
        <Typography
          id="discrete-slider"
          style={{
            fontFamily: "Fjalla One",
            direction: "rtl",
            color: "#ced4da",
          }}
        >
          {"Standard BMI Calculator"}
        </Typography>
        <Typography
          style={{
            fontFamily: "Fjalla One",
            direction: "rtl",
            color: "#ced4da",
          }}
          variant="h2"
        >
          {bmi ? countUp : 0}
        </Typography>
        <div id="first-information">
          <div className="login-form">
            <div className="login-heading-container">
              <Slider
                label={"Weight(Kg)"}
                min={40}
                max={140}
                defaultValue={70}
                setState={setWeight}
              />
              <Slider
                label={"Height(cm)"}
                min={120}
                max={240}
                defaultValue={175}
                setState={setHeight}
              />
              <Buttons gender={gender} setGender={setGender} />
            </div>
          </div>
          <Button
            variant="contained"
            color="default"
            style={{ fontFamily: "Roboto" }}
            // className={classes.button}
            startIcon={<EjectIcon />}
            onClick={()=>{
              if(!gender){
                handleClick();
                return;
              }
              const _bmi = CalculteBMI(((weight as number) + (gender==='female' ? 3 : 0)), height as number);
              setBMI(_bmi);
              update(_bmi);
              setDegree(mapping(_bmi, ranges[input(_bmi)][0], ranges[input(_bmi)][1], ranges[input(_bmi)][2], ranges[input(_bmi)][3]))
             }}
          >
            Calculate
          </Button>
        </div>

      <Snackbar open={open} autoHideDuration={4000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="warning">
        You didn't select your gender!
        </Alert>
      </Snackbar>
      </div>
    );
}

export default HW1;



const CalculteBMI = (weight:number, height:number)=> weight / (height**2) * 10000;
const mapping = (input:number, input_start:number,input_end:number,output_start:number,output_end:number )=> output_start + ((output_end - output_start) / (input_end - input_start)) * (input - input_start);
const input = (bmi:number)=>(bmi<18.5 ? 0 : (bmi>=18.5 && bmi <=24.9) ? 1 : (bmi>24.9 && bmi <=29.9) ? 2 : 3);
const ranges = [[0, 18.5, -90, -45],
                [18.5, 24.9, -45, 0],
                [24.9, 29.9, 0, 45],
                [29.9, 98, 45, 90],
] 








