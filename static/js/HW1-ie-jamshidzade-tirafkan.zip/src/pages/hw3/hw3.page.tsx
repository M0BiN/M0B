import React from "react";
import "./hw3.style.css";
import axios from "axios";
import { makeStyles, createStyles, Theme } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import Grid from "@material-ui/core/Grid";
import Button from '@material-ui/core/Button';
import DayWeather from '../../component/dayweather/dayweather.component';
import LineChart from '../../component/linechart/linechart.component';
import Barchart from '../../component/barchart/barchart.componenet';
import SearchBar from '../../component/weatherSearchbar/weatherSearchbar.component';
import WindChart from '../../component/windchart/windchart.component';
import CircularProgress from '@material-ui/core/CircularProgress';
import DayMaxMin from '../../component/daymaxminweather/daymaxminweather.component';
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      flexGrow: 1,
      display:'flex',
      justifyContent:'center',
      alignItems:'center',
      maxWidth:'700px',
      margin:'0 auto',
      backgroundColor:'rgba(255, 255, 255, 0.55)',
      borderRadius:'24px',
      padding:'18px',
      // paddingBottom:'0',
      paddingTop:'12px'
      
    },
    paper: {
      padding: theme.spacing(2),
      textAlign: "center",
      color: theme.palette.text.secondary,
    },
  })
);
function HW3() {
  const classes = useStyles();
  const [city, setCity] = React.useState<string>('');
  const [current, setCurrent] = React.useState<null | current_type>(null);
  const [location, setLocation] = React.useState<null | location_type>(null);
  const [days, setDays] = React.useState<null | days_type[]>(null);
  const [chartMode, setChartMode] = React.useState<string>(`Temperature`);
  const [currentDay, setCurrentDay] = React.useState<number>(0);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [error, setError] = React.useState<boolean>(false);
  React.useEffect(() => {
    if(!city){
      return;
    }
    setDays(null);
    setLoading(true);
    setError(false);
    axios
      .get(
        `https://api.weatherapi.com/v1/forecast.json?key=4c31d311853d4546bc2210454200412&q=${city}&days=4`
      )
      .then((d) => {
        setCurrent(d?.data?.current);
        setLocation(d?.data?.location);
        setDays(d?.data?.forecast?.forecastday);
        setLoading(false);
        // console.log(d);
      }).catch(e=>{
        setError(true);
        
      });
  }, [city]);
  if(!days){
    return <div className='hw3-container'>
      <SearchBar setCity={setCity} cityText={city || ''} wide/>
      {!error ? <CircularProgress size={80} style={{visibility:loading ? 'visible' : 'hidden'}}/> : error ?
      <Typography variant={'h1'} style={{borderRadius:'16px',color:'#424242', backgroundColor:'rgba(255, 255, 255, 0.55)', padding:'16px'}}>
        Not Found :(
        </Typography>
        :
        null}
    </div>
  }
  return (
    <div className='hw3-container'>
    <div className={classes.root}>
      <Grid container spacing={3}>
        <Grid item xs={6} > {/* cityName - time - current status*/}
          <Grid container >
            <Grid item xs={12}>
              <Typography variant="h6" align={"left"} style={{fontFamily:'Roboto', fontSize:'34px', fontWeight:900}}>
                {location ? `${location?.name}, ${location.country}` : ''}
              </Typography>
            </Grid>
            <Grid item xs={12}>
            <Typography variant="h6" align={"left"} style={{fontFamily:'Oswald',}} >
            {current?.time || location?.localtime || ''}
              </Typography>
            </Grid>
            <Grid item xs={12} >
            <Typography variant="h6" align={"left"}  style={{fontFamily:'Oswald'}}>
                {current?.condition.text || ''} 
              </Typography>
            </Grid>
          </Grid>
        </Grid>
        <Grid item xs={6}>
          
          <SearchBar setCity={setCity}/>
          <Grid container justify="center" style={{marginTop:'12px',}}>
          {
  days?.map((e, i)=>  <Grid 
  style={{cursor:'pointer',backgroundColor:i===currentDay ? 'rgba(255, 255, 255, 0.65)' : '',
  marginLeft:'12px',
   borderRadius:'16px', MozUserSelect:'none', WebkitUserSelect:'none', transition:`300ms linear`}} 
  item xs={3} onClick={()=>{
    setCurrentDay(i);
    setCurrent((o)=>({...o, ...e.hour[0]}))
    }}>
  <DayMaxMin 
    icon={e.day.condition.icon}
    min_temp={e.day.mintemp_c}
    max_temp={e.day.maxtemp_c}
    hour={i===0 ? 'Today' : getDayOfWeek(e.date)}
    />
  </Grid> )
}
          </Grid>
        </Grid>

        <Grid item xs={12} style={{marginTop:'-18px'}}>{/* current icon - current temp */}
        <Grid container>
        <Grid container  xs={6} item alignItems="center" >{/* icon */}
          <img src={current?.condition.icon.replace(/\d\dx\d\d/,"128x128")} />
          <Typography variant="h1" align={"left"} style={{fontFamily:'Oswald'}}>
                {current?.temp_c || ''}
                <Typography variant="caption" style={{verticalAlign:'top',fontFamily:'Oswald',fontSize:'18px' }} >°C</Typography>
                
              </Typography>









              
        </Grid>
        <Grid item xs={6}>{/* weather full status */}
        <Grid item xs={12} container style={{padding:'8px'}}> {/* Precipitation: Humidity Wind  */}
          
            <Grid item xs={12} >
              <Typography variant="h6" align={"left"} style={{fontFamily:'Oswald',color:'#424242'}}>
                {current?.precip_mm >= 0  ? `Precipitation: ${current?.precip_mm}%` : ``}
              </Typography>
            </Grid>
            <Grid item xs={12}>
            <Typography variant="h6" align={"left"} style={{fontFamily:'Oswald',color:'#424242'}}>
            
            {current?.humidity ? `Humidity: ${current?.humidity}%` : ``}
              </Typography>
            </Grid>
            <Grid item xs={12} >
            <Typography variant="h6" align={"left"} style={{fontFamily:'Oswald',color:'#424242'}}>
                {current?.wind_kph ? `Wind: ${current?.wind_kph} km/h` : ``}
              </Typography>
            </Grid>
        </Grid>
        </Grid>
        <Grid container item xs={12} justify="flex-end" style={{flex:'1'}}>
          <Grid container item xs={6} lg={6} style={{justifyContent:'center'}} >
          <Grid item xs={3} lg={3} >
          <Button name="Temperature"  onClick={()=>setChartMode('Temperature')} variant="contained" style={{width:'100%', fontFamily:'Fjalla One', fontSize:'12px',
          backgroundColor:chartMode==='Temperature'?'#007bb2':'', color:chartMode==='Temperature'?'white':''}}
          > Temperature</Button>
          </Grid>
          <Grid item container xs={3} lg={3} style={{marginLeft:'4px' ,justifyContent:'center'}}>
          <Button name="Precipitation"  onClick={()=>setChartMode('Precipitation')}
           variant="contained" style={{width:'100%', fontFamily:'Fjalla One', fontSize:'12px',
           backgroundColor:chartMode==='Precipitation'?'#007bb2':'', color:chartMode==='Precipitation'?'white':''}}> Precipitation</Button>
          </Grid>
          <Grid item xs={3} lg={3} style={{marginLeft:'4px', justifyContent:'center'}}>
          <Button name="Wind"  onClick={()=>setChartMode('Wind')} variant="contained" style={{width:'100%', fontFamily:'Fjalla One', fontSize:'12px',
          backgroundColor:chartMode==='Wind'?'#007bb2':'', color:chartMode==='Wind'?'white':''}}> Wind</Button>
          </Grid>
          </Grid>
        </Grid>
        </Grid>
          </Grid>
    {chartMode==='Wind' ? 
    <Grid item container justify="space-around" alignItems="center" direction="row" xs={12} style={{height:'174px'}} >
{
  days?.[currentDay]?.hour.map((e, i)=> i % 3 === 0 ? 
  <Grid style={{cursor:'pointer', MozUserSelect:'none', WebkitUserSelect:'none'}} item xs={1}>
  <WindChart  wind_dir={e.wind_dir} wind_speed={e.wind_kph} hour={e.time.substring(e.time.length - 5)}/>
  </Grid> : null)
}
    </Grid>
    
    :
    <Grid item xs={12} style={{height:'174px'}}>{/* charts */}
    { chartMode === 'Precipitation' ?
            <Barchart data={days?.[currentDay]?.hour.filter((v, i)=>i%3===0).map(v=>v.precip_mm)} label={days?.[currentDay]?.hour.filter((v, i)=>i%3===0).map(v=>v.time.substring(v.time.length - 5))} /> 
            : 'Temperature' ? 
            <LineChart data={days?.[currentDay]?.hour.filter((v, i)=>i%3===0).map(v=>v.temp_c)} label={days?.[currentDay]?.hour.filter((v, i)=>i%3===0).map(v=>v.time.substring(v.time.length - 5))} />
            
            :
            null
          }
            </Grid>
    }
        
        <Grid item xs={12} container justify="space-around" direction="row">{/* days */}


{
  days?.[currentDay]?.hour.map((e, i)=> i % 3 === 0 ? <Grid style={{cursor:'pointer', MozUserSelect:'none', WebkitUserSelect:'none'}} item xs={1} onClick={()=>setCurrent((o)=>({...o,...e }))}>
  <DayWeather icon={e.condition.icon} temp={e.temp_c} hour={e.time.substring(e.time.length - 5)}/>
  </Grid> : null)
}
        
        </Grid>
        <Grid item xs={12} container justify="space-around" direction="row">{/* days */}


        
        </Grid>
      </Grid>
    </div>
    </div>
  );
}

export default HW3;










// Accepts a Date object or date string that is recognized by the Date.parse() method
function getDayOfWeek(date) {
  const dayOfWeek = new Date(date).getDay();    
  return isNaN(dayOfWeek) ? null : 
    ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][dayOfWeek].substring(0, 3);
}













type current_type = {
  last_updated_epoch: number;
  last_updated: string;
  temp_c: number;
  temp_f: number;
  is_day: number;
  condition: {
    text: string;
    icon: string;
    code: number;
  };
  wind_mph: number;
  wind_kph: number;
  wind_degree: number;
  wind_dir: string;
  pressure_mb: number;
  pressure_in: number;
  precip_mm: number;
  precip_in: number;
  humidity: number;
  cloud: number;
  feelslike_c: number;
  feelslike_f: number;
  vis_km: number;
  vis_miles: number;
  uv: number;
  gust_mph: number;
  gust_kph: number;
  time?:string;
};


type location_type = {
  "name": "Ilam",
  "region": "Ilam",
  "country": "Iran",
  "lat": 33.64,
  "lon": 46.42,
  "tz_id": "Asia/Tehran",
  "localtime_epoch": 1607118713,
  "localtime": "2020-12-05 1:21"
}


type days_type = 
  {
    "date": "2020-12-05",
    "date_epoch": 1607126400,
    "day": {
      "maxtemp_c": 12.1,
      "maxtemp_f": 53.8,
      "mintemp_c": 7.1,
      "mintemp_f": 44.8,
      "avgtemp_c": 9.8,
      "avgtemp_f": 49.7,
      "maxwind_mph": 5.4,
      "maxwind_kph": 8.6,
      "totalprecip_mm": 0.2,
      "totalprecip_in": 0.01,
      "avgvis_km": 9.9,
      "avgvis_miles": 6,
      "avghumidity": 64,
      "daily_will_it_rain": 1,
      "daily_chance_of_rain": "71",
      "daily_will_it_snow": 0,
      "daily_chance_of_snow": "0",
      "condition": {
        "text": "Patchy rain possible",
        "icon": "//cdn.weatherapi.com/weather/64x64/day/176.png",
        "code": 1063
      },
      "uv": 3
    },
    "astro": {
      "sunrise": "07:14 AM",
      "sunset": "05:16 PM",
      "moonrise": "09:47 PM",
      "moonset": "11:22 AM",
      "moon_phase": "Last Quarter",
      "moon_illumination": "62"
    },
    "hour": [
      {
        "time_epoch": 1607113800,
        "time": "2020-12-05 00:00",
        "temp_c": 8.7,
        "temp_f": 47.7,
        "is_day": 0,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/116.png",
          "code": 1003
        },
        "wind_mph": 3.1,
        "wind_kph": 5,
        "wind_degree": 168,
        "wind_dir": "SSE",
        "pressure_mb": 1017,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 74,
        "cloud": 7,
        "feelslike_c": 8.3,
        "feelslike_f": 46.9,
        "windchill_c": 8.3,
        "windchill_f": 46.9,
        "heatindex_c": 8.7,
        "heatindex_f": 47.7,
        "dewpoint_c": 4.3,
        "dewpoint_f": 39.7,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 6,
        "gust_kph": 9.7
      },
      {
        "time_epoch": 1607117400,
        "time": "2020-12-05 01:00",
        "temp_c": 8.4,
        "temp_f": 47.1,
        "is_day": 0,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/116.png",
          "code": 1003
        },
        "wind_mph": 2.7,
        "wind_kph": 4.3,
        "wind_degree": 172,
        "wind_dir": "S",
        "pressure_mb": 1017,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 74,
        "cloud": 6,
        "feelslike_c": 8.2,
        "feelslike_f": 46.8,
        "windchill_c": 8.2,
        "windchill_f": 46.8,
        "heatindex_c": 8.4,
        "heatindex_f": 47.1,
        "dewpoint_c": 4.1,
        "dewpoint_f": 39.4,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 5.4,
        "gust_kph": 8.6
      },
      {
        "time_epoch": 1607121000,
        "time": "2020-12-05 02:00",
        "temp_c": 8,
        "temp_f": 46.4,
        "is_day": 0,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/116.png",
          "code": 1003
        },
        "wind_mph": 2.5,
        "wind_kph": 4,
        "wind_degree": 176,
        "wind_dir": "S",
        "pressure_mb": 1017,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 75,
        "cloud": 6,
        "feelslike_c": 8,
        "feelslike_f": 46.4,
        "windchill_c": 8,
        "windchill_f": 46.4,
        "heatindex_c": 8,
        "heatindex_f": 46.4,
        "dewpoint_c": 3.8,
        "dewpoint_f": 38.8,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 4.7,
        "gust_kph": 7.6
      },
      {
        "time_epoch": 1607124600,
        "time": "2020-12-05 03:00",
        "temp_c": 7.7,
        "temp_f": 45.9,
        "is_day": 0,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/116.png",
          "code": 1003
        },
        "wind_mph": 2,
        "wind_kph": 3.2,
        "wind_degree": 179,
        "wind_dir": "S",
        "pressure_mb": 1016,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 75,
        "cloud": 5,
        "feelslike_c": 7.9,
        "feelslike_f": 46.2,
        "windchill_c": 7.9,
        "windchill_f": 46.2,
        "heatindex_c": 7.7,
        "heatindex_f": 45.9,
        "dewpoint_c": 3.6,
        "dewpoint_f": 38.5,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 4,
        "gust_kph": 6.5
      },
      {
        "time_epoch": 1607128200,
        "time": "2020-12-05 04:00",
        "temp_c": 7.5,
        "temp_f": 45.5,
        "is_day": 0,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/116.png",
          "code": 1003
        },
        "wind_mph": 2.7,
        "wind_kph": 4.3,
        "wind_degree": 167,
        "wind_dir": "SSE",
        "pressure_mb": 1017,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 72,
        "cloud": 6,
        "feelslike_c": 7.3,
        "feelslike_f": 45.1,
        "windchill_c": 7.3,
        "windchill_f": 45.1,
        "heatindex_c": 7.5,
        "heatindex_f": 45.5,
        "dewpoint_c": 2.8,
        "dewpoint_f": 37,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 5.6,
        "gust_kph": 9
      },
      {
        "time_epoch": 1607131800,
        "time": "2020-12-05 05:00",
        "temp_c": 7.3,
        "temp_f": 45.1,
        "is_day": 0,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/116.png",
          "code": 1003
        },
        "wind_mph": 3.4,
        "wind_kph": 5.4,
        "wind_degree": 156,
        "wind_dir": "SSE",
        "pressure_mb": 1017,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 69,
        "cloud": 6,
        "feelslike_c": 6.6,
        "feelslike_f": 43.9,
        "windchill_c": 6.6,
        "windchill_f": 43.9,
        "heatindex_c": 7.3,
        "heatindex_f": 45.1,
        "dewpoint_c": 1.9,
        "dewpoint_f": 35.4,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 6.9,
        "gust_kph": 11.2
      },
      {
        "time_epoch": 1607135400,
        "time": "2020-12-05 06:00",
        "temp_c": 7.1,
        "temp_f": 44.8,
        "is_day": 0,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/116.png",
          "code": 1003
        },
        "wind_mph": 4,
        "wind_kph": 6.5,
        "wind_degree": 144,
        "wind_dir": "SE",
        "pressure_mb": 1017,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 65,
        "cloud": 6,
        "feelslike_c": 6,
        "feelslike_f": 42.8,
        "windchill_c": 6,
        "windchill_f": 42.8,
        "heatindex_c": 7.1,
        "heatindex_f": 44.8,
        "dewpoint_c": 1.1,
        "dewpoint_f": 34,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 8.5,
        "gust_kph": 13.7
      },
      {
        "time_epoch": 1607139000,
        "time": "2020-12-05 07:00",
        "temp_c": 8.2,
        "temp_f": 46.8,
        "is_day": 1,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/day/116.png",
          "code": 1003
        },
        "wind_mph": 4.5,
        "wind_kph": 7.2,
        "wind_degree": 146,
        "wind_dir": "SSE",
        "pressure_mb": 1017,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 61,
        "cloud": 7,
        "feelslike_c": 7.1,
        "feelslike_f": 44.8,
        "windchill_c": 7.1,
        "windchill_f": 44.8,
        "heatindex_c": 8.2,
        "heatindex_f": 46.8,
        "dewpoint_c": 0.9,
        "dewpoint_f": 33.6,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 8.1,
        "gust_kph": 13
      },
      {
        "time_epoch": 1607142600,
        "time": "2020-12-05 08:00",
        "temp_c": 9.3,
        "temp_f": 48.7,
        "is_day": 1,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/day/116.png",
          "code": 1003
        },
        "wind_mph": 4.9,
        "wind_kph": 7.9,
        "wind_degree": 148,
        "wind_dir": "SSE",
        "pressure_mb": 1017,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 56,
        "cloud": 7,
        "feelslike_c": 8.2,
        "feelslike_f": 46.8,
        "windchill_c": 8.2,
        "windchill_f": 46.8,
        "heatindex_c": 9.3,
        "heatindex_f": 48.7,
        "dewpoint_c": 0.8,
        "dewpoint_f": 33.4,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 7.8,
        "gust_kph": 12.6
      },
      {
        "time_epoch": 1607146200,
        "time": "2020-12-05 09:00",
        "temp_c": 10.4,
        "temp_f": 50.7,
        "is_day": 1,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/day/116.png",
          "code": 1003
        },
        "wind_mph": 5.4,
        "wind_kph": 8.6,
        "wind_degree": 151,
        "wind_dir": "SSE",
        "pressure_mb": 1017,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 51,
        "cloud": 7,
        "feelslike_c": 9.3,
        "feelslike_f": 48.7,
        "windchill_c": 9.3,
        "windchill_f": 48.7,
        "heatindex_c": 10.4,
        "heatindex_f": 50.7,
        "dewpoint_c": 0.6,
        "dewpoint_f": 33.1,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 7.4,
        "gust_kph": 11.9
      },
      {
        "time_epoch": 1607149800,
        "time": "2020-12-05 10:00",
        "temp_c": 11,
        "temp_f": 51.8,
        "is_day": 1,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/day/116.png",
          "code": 1003
        },
        "wind_mph": 5.4,
        "wind_kph": 8.6,
        "wind_degree": 167,
        "wind_dir": "SSE",
        "pressure_mb": 1016,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 51,
        "cloud": 11,
        "feelslike_c": 10,
        "feelslike_f": 50,
        "windchill_c": 10,
        "windchill_f": 50,
        "heatindex_c": 11,
        "heatindex_f": 51.8,
        "dewpoint_c": 1.1,
        "dewpoint_f": 34,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 6.9,
        "gust_kph": 11.2
      },
      {
        "time_epoch": 1607153400,
        "time": "2020-12-05 11:00",
        "temp_c": 11.5,
        "temp_f": 52.7,
        "is_day": 1,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/day/116.png",
          "code": 1003
        },
        "wind_mph": 5.4,
        "wind_kph": 8.6,
        "wind_degree": 184,
        "wind_dir": "S",
        "pressure_mb": 1016,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 51,
        "cloud": 14,
        "feelslike_c": 10.7,
        "feelslike_f": 51.3,
        "windchill_c": 10.7,
        "windchill_f": 51.3,
        "heatindex_c": 11.5,
        "heatindex_f": 52.7,
        "dewpoint_c": 1.7,
        "dewpoint_f": 35.1,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 6.7,
        "gust_kph": 10.8
      },
      {
        "time_epoch": 1607157000,
        "time": "2020-12-05 12:00",
        "temp_c": 12.1,
        "temp_f": 53.8,
        "is_day": 1,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/day/116.png",
          "code": 1003
        },
        "wind_mph": 5.4,
        "wind_kph": 8.6,
        "wind_degree": 201,
        "wind_dir": "SSW",
        "pressure_mb": 1015,
        "pressure_in": 30.5,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 51,
        "cloud": 18,
        "feelslike_c": 11.4,
        "feelslike_f": 52.5,
        "windchill_c": 11.4,
        "windchill_f": 52.5,
        "heatindex_c": 12.1,
        "heatindex_f": 53.8,
        "dewpoint_c": 2.2,
        "dewpoint_f": 36,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 6.3,
        "gust_kph": 10.1
      },
      {
        "time_epoch": 1607160600,
        "time": "2020-12-05 13:00",
        "temp_c": 12,
        "temp_f": 53.6,
        "is_day": 1,
        "condition": {
          "text": "Patchy rain possible",
          "icon": "//cdn.weatherapi.com/weather/64x64/day/176.png",
          "code": 1063
        },
        "wind_mph": 4.3,
        "wind_kph": 6.8,
        "wind_degree": 201,
        "wind_dir": "SSW",
        "pressure_mb": 1015,
        "pressure_in": 30.4,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 53,
        "cloud": 41,
        "feelslike_c": 11.7,
        "feelslike_f": 53.1,
        "windchill_c": 11.7,
        "windchill_f": 53.1,
        "heatindex_c": 12,
        "heatindex_f": 53.6,
        "dewpoint_c": 2.8,
        "dewpoint_f": 37,
        "will_it_rain": 0,
        "chance_of_rain": "24",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 4.9,
        "gust_kph": 7.9
      },
      {
        "time_epoch": 1607164200,
        "time": "2020-12-05 14:00",
        "temp_c": 11.9,
        "temp_f": 53.4,
        "is_day": 1,
        "condition": {
          "text": "Partly cloudy",
          "icon": "//cdn.weatherapi.com/weather/64x64/day/116.png",
          "code": 1003
        },
        "wind_mph": 3.1,
        "wind_kph": 5,
        "wind_degree": 202,
        "wind_dir": "SSW",
        "pressure_mb": 1014,
        "pressure_in": 30.4,
        "precip_mm": 0.1,
        "precip_in": 0,
        "humidity": 56,
        "cloud": 65,
        "feelslike_c": 12.1,
        "feelslike_f": 53.8,
        "windchill_c": 12.1,
        "windchill_f": 53.8,
        "heatindex_c": 11.9,
        "heatindex_f": 53.4,
        "dewpoint_c": 3.3,
        "dewpoint_f": 37.9,
        "will_it_rain": 0,
        "chance_of_rain": "47",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 3.6,
        "gust_kph": 5.8
      },
      {
        "time_epoch": 1607167800,
        "time": "2020-12-05 15:00",
        "temp_c": 11.8,
        "temp_f": 53.2,
        "is_day": 1,
        "condition": {
          "text": "Patchy rain possible",
          "icon": "//cdn.weatherapi.com/weather/64x64/day/176.png",
          "code": 1063
        },
        "wind_mph": 2,
        "wind_kph": 3.2,
        "wind_degree": 202,
        "wind_dir": "SSW",
        "pressure_mb": 1013,
        "pressure_in": 30.4,
        "precip_mm": 0.1,
        "precip_in": 0,
        "humidity": 58,
        "cloud": 88,
        "feelslike_c": 12.4,
        "feelslike_f": 54.3,
        "windchill_c": 12.4,
        "windchill_f": 54.3,
        "heatindex_c": 11.8,
        "heatindex_f": 53.2,
        "dewpoint_c": 3.9,
        "dewpoint_f": 39,
        "will_it_rain": 1,
        "chance_of_rain": "71",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 2.2,
        "gust_kph": 3.6
      },
      {
        "time_epoch": 1607171400,
        "time": "2020-12-05 16:00",
        "temp_c": 11.5,
        "temp_f": 52.7,
        "is_day": 1,
        "condition": {
          "text": "Thundery outbreaks possible",
          "icon": "//cdn.weatherapi.com/weather/64x64/day/200.png",
          "code": 1087
        },
        "wind_mph": 1.8,
        "wind_kph": 2.9,
        "wind_degree": 206,
        "wind_dir": "SSW",
        "pressure_mb": 1013,
        "pressure_in": 30.4,
        "precip_mm": 0.1,
        "precip_in": 0,
        "humidity": 62,
        "cloud": 76,
        "feelslike_c": 11.9,
        "feelslike_f": 53.4,
        "windchill_c": 11.9,
        "windchill_f": 53.4,
        "heatindex_c": 11.5,
        "heatindex_f": 52.7,
        "dewpoint_c": 4.3,
        "dewpoint_f": 39.7,
        "will_it_rain": 0,
        "chance_of_rain": "47",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 9.7,
        "vis_miles": 6,
        "gust_mph": 2,
        "gust_kph": 3.2
      },
      {
        "time_epoch": 1607175000,
        "time": "2020-12-05 17:00",
        "temp_c": 11.1,
        "temp_f": 52,
        "is_day": 0,
        "condition": {
          "text": "Patchy rain possible",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/176.png",
          "code": 1063
        },
        "wind_mph": 1.6,
        "wind_kph": 2.5,
        "wind_degree": 210,
        "wind_dir": "SSW",
        "pressure_mb": 1013,
        "pressure_in": 30.4,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 65,
        "cloud": 64,
        "feelslike_c": 11.3,
        "feelslike_f": 52.3,
        "windchill_c": 11.3,
        "windchill_f": 52.3,
        "heatindex_c": 11.1,
        "heatindex_f": 52,
        "dewpoint_c": 4.8,
        "dewpoint_f": 40.6,
        "will_it_rain": 0,
        "chance_of_rain": "24",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 9.3,
        "vis_miles": 5,
        "gust_mph": 2,
        "gust_kph": 3.2
      },
      {
        "time_epoch": 1607178600,
        "time": "2020-12-05 18:00",
        "temp_c": 10.8,
        "temp_f": 51.4,
        "is_day": 0,
        "condition": {
          "text": "Thundery outbreaks possible",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/200.png",
          "code": 1087
        },
        "wind_mph": 1.3,
        "wind_kph": 2.2,
        "wind_degree": 214,
        "wind_dir": "SW",
        "pressure_mb": 1013,
        "pressure_in": 30.4,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 68,
        "cloud": 52,
        "feelslike_c": 10.8,
        "feelslike_f": 51.4,
        "windchill_c": 10.8,
        "windchill_f": 51.4,
        "heatindex_c": 10.8,
        "heatindex_f": 51.4,
        "dewpoint_c": 5.2,
        "dewpoint_f": 41.4,
        "will_it_rain": 0,
        "chance_of_rain": "0",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 9,
        "vis_miles": 5,
        "gust_mph": 1.8,
        "gust_kph": 2.9
      },
      {
        "time_epoch": 1607182200,
        "time": "2020-12-05 19:00",
        "temp_c": 10.5,
        "temp_f": 50.9,
        "is_day": 0,
        "condition": {
          "text": "Patchy rain possible",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/176.png",
          "code": 1063
        },
        "wind_mph": 2.2,
        "wind_kph": 3.6,
        "wind_degree": 199,
        "wind_dir": "SSW",
        "pressure_mb": 1013,
        "pressure_in": 30.4,
        "precip_mm": 0,
        "precip_in": 0,
        "humidity": 69,
        "cloud": 52,
        "feelslike_c": 10.3,
        "feelslike_f": 50.5,
        "windchill_c": 10.3,
        "windchill_f": 50.5,
        "heatindex_c": 10.5,
        "heatindex_f": 50.9,
        "dewpoint_c": 5.1,
        "dewpoint_f": 41.2,
        "will_it_rain": 0,
        "chance_of_rain": "21",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 9.3,
        "vis_miles": 5,
        "gust_mph": 3.1,
        "gust_kph": 5
      },
      {
        "time_epoch": 1607185800,
        "time": "2020-12-05 20:00",
        "temp_c": 10.3,
        "temp_f": 50.5,
        "is_day": 0,
        "condition": {
          "text": "Thundery outbreaks possible",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/200.png",
          "code": 1087
        },
        "wind_mph": 2.9,
        "wind_kph": 4.7,
        "wind_degree": 185,
        "wind_dir": "S",
        "pressure_mb": 1013,
        "pressure_in": 30.4,
        "precip_mm": 0.1,
        "precip_in": 0,
        "humidity": 70,
        "cloud": 52,
        "feelslike_c": 9.9,
        "feelslike_f": 49.8,
        "windchill_c": 9.9,
        "windchill_f": 49.8,
        "heatindex_c": 10.3,
        "heatindex_f": 50.5,
        "dewpoint_c": 5.1,
        "dewpoint_f": 41.2,
        "will_it_rain": 0,
        "chance_of_rain": "43",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 9.7,
        "vis_miles": 6,
        "gust_mph": 4.5,
        "gust_kph": 7.2
      },
      {
        "time_epoch": 1607189400,
        "time": "2020-12-05 21:00",
        "temp_c": 10,
        "temp_f": 50,
        "is_day": 0,
        "condition": {
          "text": "Patchy rain possible",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/176.png",
          "code": 1063
        },
        "wind_mph": 3.8,
        "wind_kph": 6.1,
        "wind_degree": 170,
        "wind_dir": "S",
        "pressure_mb": 1013,
        "pressure_in": 30.4,
        "precip_mm": 0.1,
        "precip_in": 0,
        "humidity": 71,
        "cloud": 52,
        "feelslike_c": 9.4,
        "feelslike_f": 48.9,
        "windchill_c": 9.4,
        "windchill_f": 48.9,
        "heatindex_c": 10,
        "heatindex_f": 50,
        "dewpoint_c": 5,
        "dewpoint_f": 41,
        "will_it_rain": 0,
        "chance_of_rain": "64",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 5.8,
        "gust_kph": 9.4
      },
      {
        "time_epoch": 1607193000,
        "time": "2020-12-05 22:00",
        "temp_c": 9.4,
        "temp_f": 48.9,
        "is_day": 0,
        "condition": {
          "text": "Light rain shower",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/353.png",
          "code": 1240
        },
        "wind_mph": 3.8,
        "wind_kph": 6.1,
        "wind_degree": 187,
        "wind_dir": "S",
        "pressure_mb": 1013,
        "pressure_in": 30.4,
        "precip_mm": 0.4,
        "precip_in": 0.02,
        "humidity": 75,
        "cloud": 68,
        "feelslike_c": 8.7,
        "feelslike_f": 47.7,
        "windchill_c": 8.7,
        "windchill_f": 47.7,
        "heatindex_c": 9.4,
        "heatindex_f": 48.9,
        "dewpoint_c": 5.1,
        "dewpoint_f": 41.2,
        "will_it_rain": 1,
        "chance_of_rain": "74",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 5.4,
        "gust_kph": 8.6
      },
      {
        "time_epoch": 1607196600,
        "time": "2020-12-05 23:00",
        "temp_c": 8.7,
        "temp_f": 47.7,
        "is_day": 0,
        "condition": {
          "text": "Patchy rain possible",
          "icon": "//cdn.weatherapi.com/weather/64x64/night/176.png",
          "code": 1063
        },
        "wind_mph": 3.6,
        "wind_kph": 5.8,
        "wind_degree": 204,
        "wind_dir": "SSW",
        "pressure_mb": 1013,
        "pressure_in": 30.4,
        "precip_mm": 0.8,
        "precip_in": 0.03,
        "humidity": 79,
        "cloud": 84,
        "feelslike_c": 8.1,
        "feelslike_f": 46.6,
        "windchill_c": 8.1,
        "windchill_f": 46.6,
        "heatindex_c": 8.7,
        "heatindex_f": 47.7,
        "dewpoint_c": 5.3,
        "dewpoint_f": 41.5,
        "will_it_rain": 1,
        "chance_of_rain": "83",
        "will_it_snow": 0,
        "chance_of_snow": "0",
        "vis_km": 10,
        "vis_miles": 6,
        "gust_mph": 4.9,
        "gust_kph": 7.9
      }
    ]
  };
