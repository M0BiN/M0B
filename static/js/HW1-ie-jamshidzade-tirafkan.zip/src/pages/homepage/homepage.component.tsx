import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardActionArea from "@material-ui/core/CardActionArea";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
import Typography from "@material-ui/core/Typography";
import img1 from "../../assets/images/hw1.jpg";
import img2 from "../../assets/images/hw2.jpg";
import img3 from "../../assets/images/hw3.jpg";
import img4 from "../../assets/images/hw4.jpg";
import img5 from "../../assets/images/hw5.jpg";
import img6 from "../../assets/images/hw6.jpg";
import img7 from "../../assets/images/hw7.jpg";
import Grid from "@material-ui/core/Grid";
import {useHistory} from "react-router-dom";
import "./homepage.style.css";

const useStyles = makeStyles({
  root: {
    width: "100%",
    margin: "14px",
    marginBottom: "0",
  },
  media: {
    height: 140,
  },
});

export default function MediaCard() {
  const classes = useStyles();
  const history = useHistory();
  
  return (
    <Grid
      container
      justify="center"
      alignItems="center"
      
      style={{
        padding: "84px",
        backgroundColor: "#e0e0e0",
        width: "100vw",
        height: "100vh",
      }}
    >
      {data.map((v, i)=><Grid item xs={2} style={{margin:'16px', height:'100px', width:'100px'}}>
        <Card className={classes.root} key={`homecard${i}`} onClick={()=>history.push(v.link)}>
          <CardActionArea>
            <CardMedia
              className={classes.media}
              image={v.image}
              title="Contemplative Reptile"
            />
            <CardContent>
              <Typography
                gutterBottom
                variant="h5"
                component="h2"
                style={{ fontFamily: "Yekan" }}
              >
                {v.label}
              </Typography>
            </CardContent>
          </CardActionArea>
        </Card>
      </Grid>
      )
      }
    </Grid>
  );
}

const data = [
  { image: img1, label: "BMI", link: "HW1" },
  { image: img2, label: "تغییر رنگ", link: "HW2" },
  { image: img3, label: "پیش بینی آب و هوا", link: "HW3" },
  { image: img4, label: "شبکه ی اجتماعی", link: "HW4" },
  { image: img5, label: "مترونوم", link: "HW5" },
  { image: img6, label: "کارت بانکی", link: "HW6" },
  { image: img7, label: "تبدیل مبنا", link: "HW7" },
];
