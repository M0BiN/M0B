import React from "react";
import "./hw7.style.css";
import Input from "../../component/input/input.component";
function HW7() {
  const [number, setNumber] = React.useState(`0`);
  return (
    <div className="hw7-container" >
      <h1 style={{fontFamily:'Fjalla One', color:'#3b4148'}}>Convert numbers from one base to another</h1>
      <div className="base-container">
        <div className="grid">
          <div className="form login">
            <Input number={number} setNumber={setNumber} base={2} />
            <Input number={number} setNumber={setNumber} base={3} />
            <Input number={number} setNumber={setNumber} base={4} />
            <Input number={number} setNumber={setNumber} base={5} />
            <Input number={number} setNumber={setNumber} base={6} />
            <Input number={number} setNumber={setNumber} base={7} />
            <Input number={number} setNumber={setNumber} base={8} />
          </div>
        </div>
        <div className="grid">
          <div className="form login">
            <Input number={number} setNumber={setNumber} base={9} />
            <Input number={number} setNumber={setNumber} base={11} />
            <Input number={number} setNumber={setNumber} base={12} />
            <Input number={number} setNumber={setNumber} base={13} />
            <Input number={number} setNumber={setNumber} base={14} />
            <Input number={number} setNumber={setNumber} base={15} />
            <Input number={number} setNumber={setNumber} base={16} />
          </div>
        </div>
      </div>
      <div className="grid" style={{ margin: `0 auto` }}>
        <div className="form login">
          <Input number={number} setNumber={setNumber} base={10} isSpecial={true} />
        </div>
      </div>
    </div>
  );
}

export default HW7;
