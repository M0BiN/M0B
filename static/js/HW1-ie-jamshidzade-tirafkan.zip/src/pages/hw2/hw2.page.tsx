import React from "react";
import "./hw2.style.css";
import Typography from "@material-ui/core/Typography";
import {
  CirclePicker,
  BlockPicker,
  ChromePicker,
  GithubPicker,
  SketchPicker,
  SwatchesPicker
} from "react-color";

function HW2() {
  const [color, setColor] = React.useState(`#fafafa`);
  const child1 = React.useRef<any>(null);

  const onChangeComplete = (color: any) => setColor(color.hex);
  return (
    <div
      style={{
        backgroundColor: color,
        minHeight: "100vh",
        transition: "all .5s ease",
        WebkitTransition: "all .5s ease",
        MozTransition: "all .5s ease",
        height:'100vh'
      }}
    >
      <Typography
        style={{
          fontFamily: "Fjalla One",
          // direction: "rtl",
          color: "#ced4da",
        }}
        variant="h1"
      >
        {"Hello, World!"}
      </Typography>
      <div className="table-plate" id="style-4" ref={child1} >
        <div className="scroll-content" >
          <CirclePicker
            color={color}
            onChangeComplete={onChangeComplete}
          />
        </div>

        <div className="scroll-content">
          <BlockPicker
            color={color}
            onChangeComplete={onChangeComplete}
          />
        </div>

        <div className="scroll-content">
          <SwatchesPicker
            color={color}
            onChangeComplete={onChangeComplete}
            
          />
        </div>

        <div className="scroll-content">
          <ChromePicker
            color={color}
            onChangeComplete={onChangeComplete}
          />
        </div>

        <div className="scroll-content">
          <GithubPicker
            color={color}
            onChangeComplete={onChangeComplete}
          />
        </div>

      </div>
      {/* <button onClick={()=>{
        console.log(child1);
        child1.current.scrollLeft += 20 ;
      }}>

      </button> */}
    </div>
  );
}

export default HW2;
