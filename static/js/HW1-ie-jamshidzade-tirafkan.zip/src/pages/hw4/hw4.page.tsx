import React from "react";
import "./hw4.style.css";
import TweetCard from "../../component/tweetCard/tweetCard.component";
import Seachbar from "../../component/searchbar/searchbar.component";
import List from "../../component/list/list.component";
import SettingList from "../../component/settingList/settingList.component";
import TweetInput from "../../component/tweetInput/tweetInput.component";
import MiddleHeader from "../../component/middleHeader/middleHeader.component";
import { AnimateGroup } from "react-animation";
import TweetDialog from "../../component/tweetDialog/tweetDialog.component";
import TrendList from '../../component/trendlist/trendlist.componenet';
function HW4() {
  const [tweets, setTweets] = React.useState(initialTweets);
  const [open, setOpen] = React.useState(false);
  const [replyTweet, setReplyTweet] = React.useState(0);
  const [acc_suggestion, setAcc_suggestion] = React.useState(initial_acc_suggestion);
  const [trends_suggestion, setTrends_suggestion] = React.useState(initial_trends_suggestion);
  const [focusedTweet, setFocusedTweet] = React.useState<number | null>(null);

  return (
    <div className="hw4-container">
      <div className="hw4-left-container">
        <SettingList />
      </div>
      <div className="hw4-center-container">
        <MiddleHeader
          focusedTweet={focusedTweet}
          setFocusedTweet={setFocusedTweet}
        />
        {!focusedTweet && focusedTweet !== 0 ? (
          <>
            <TweetInput setChange={setTweets} />
            <AnimateGroup animation="bounce">
              {tweets.map((e, i) => (
                <TweetCard
                  setFocusedTweet={setFocusedTweet}
                  tweet={{ ...e, index: i, setChange: setTweets }}
                  setReplyTweet={setReplyTweet}
                  setDialogOpen={setOpen}
                />
              ))}
            </AnimateGroup>
          </>
        ) : (
          <>
          <TweetCard
            tweet={{
              ...tweets[focusedTweet],
              setChange: setTweets,
              index: focusedTweet,
            }}
            setReplyTweet={setReplyTweet}
            setDialogOpen={setOpen}
          />
          {tweets[focusedTweet].replys.map((e, i) => (
                <TweetCard
                  setFocusedTweet={setFocusedTweet}
                  tweet={{ ...e, index: i, setChange: setTweets, username:e.username + ' Reply to ' + tweets[focusedTweet].username,  }}
                  setReplyTweet={setReplyTweet}
                  setDialogOpen={setOpen}
                />
              ))}
          </>
        )
      }
      </div>
      <div className="hw4-right-container">
        <Seachbar />
        <List acc_suggestion={acc_suggestion} setAcc_suggestion={setAcc_suggestion} />
        <TrendList acc_suggestion={trends_suggestion} setAcc_suggestion={setTrends_suggestion}/>
        {/* <List acc_suggestion={acc_suggestion} setAcc_suggestion={setAcc_suggestion}/> */}
      </div>
      <TweetDialog
        tweet={tweets[replyTweet]}
        open={open}
        setOpen={setOpen}
        index={replyTweet}
        setChange={setTweets}
      />
    </div>
  );
}

export default HW4;
let initialTweets = [
  {
    text: `Jaguars have a more powerful bite than any other big cat. Their teeth are strong enough to bite through the thick hides of crocodilians and the hard shells of turtles.`,
    image:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Jaguar.jpg/1200px-Jaguar.jpg",
    username: "@_Ari4Nna_i",
    name: "Arianna Almendarez ",
    isLiked: false,
    isRetweeted: false,
    totalLike: "99",
    totalRetweet: "70",
    replys: [
      {
        text: `hmm... interesting!`,
        image:"",
        username: "@sdagonzo",
        name: "Gonzales",
        isLiked: false,
        isRetweeted: false,
        totalLike: "0",
        totalRetweet: "0",
        replyedTweet:0,
        isReplyed:true,
        replys:[]
      },
    ],
  },
  {
    text: `Fun Fact of the day: Grapes light on fire in the microwave!`,
    image:
      "",
    username: "@federico",
    name: "Federico Chiesa",
    isLiked: false,
    isRetweeted: false,
    totalLike: "29",
    totalRetweet: "3",
    replys: [],
  },
  {
    text: `Apple Tree Nature :)`,
    image:
      "https://cdn.pixabay.com/photo/2018/06/22/16/02/apple-tree-3491025_960_720.jpg",
    username: "@animalWhatcher2",
    name: "Christopher Columbus",
    isLiked: false,
    isRetweeted: false,
    totalLike: "75",
    totalRetweet: "28",
    replys: [],
  },

];
let initial_acc_suggestion = [
  {
    name:`Tuija Nur`,
    username:`@tuija_mur`,
    isFollowed:false
  },
  {
    name:`Quidel Arevig`,
    username:`@mr_arevig`,
    isFollowed:false
  },
  {
    name:`Kimimela Vazgen`,
    username:`@thekimimelavazgen`,
    isFollowed:false
  }
]
let initial_trends_suggestion = [
  {
    name:`#RESONANCEwithNCT`,
    username:`307K Tweets`,
    
  },
  {
    name:`#REUNION`,
    username:`56.8K Tweets`,
    
  },
  {
    name:`#ガチで欲しいもの5選`,
    username:`9,881 Tweets`,
    
  },
  // {
  //   name:`#WeLoveYouHyunjin`,
  //   username:`154K Tweets`,
    
  // },
]