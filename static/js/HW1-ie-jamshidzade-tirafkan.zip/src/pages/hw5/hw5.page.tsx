import React from "react";

import tap0 from '../../assets/audio/0tap.mp3';
import mtrsnd from '../../assets/audio/mtrsnd.mp3';

import "./hw5.style.css";
import PrettoSlider from "../../component/prettoSlider/prettoSlider.component";
import { Fab } from "@material-ui/core";
import PlayArrowIcon from "@material-ui/icons/PlayArrow";
import PauseIcon from "@material-ui/icons/Pause";
import Typography from "@material-ui/core/Typography";
import IconButton from "@material-ui/core/IconButton";
import AddCircleIcon from "@material-ui/icons/AddCircle";
import RemoveCircleIcon from "@material-ui/icons/RemoveCircle";

let start: any;

function HW5() {
  const [isPlay, setIsPlay] = React.useState(false);
  const [bpm, setBpm] = React.useState(40);
  const [count, setCount] = React.useState(0);
  const [dot, setDot] = React.useState(2);
  const handleChange = () => setIsPlay((o) => !o);
  React.useEffect(() => {
    clearInterval(start);
    if (isPlay) {
      start = setInterval(() => {
        setCount((o: number) => (o < dot - 1 ? o + 1 : 0));
      }, 60000 / bpm);
    }
  }, [bpm, isPlay, dot]);

  React.useEffect(() => {
    if(!isPlay)return;
    if (start) {
      if (count === 0) {
        new Audio(tap0).play();
      } else {
        new Audio(mtrsnd).play();
      }
    }
  }, [count]);

  return (
    <div
      className="hw5-container"
      onClick={() => {
        // new Audio(`http://mb4e.tk/metronome.mp3`).play();
      }}
    >
      <tbody>
        <tr
          className="btn--circle"
          style={{ justifyContent: "space-between", marginTop: "-80px" }}
        >
          {Array(dot)
            .fill(1)
            .map((v, i) => (
              
                <td
                  key={`${i}TdDot`}
                  className="btn"
                  style={{
                    display: "inline-block",
                    opacity: "1",
                    visibility: "visible",
                    background:
                      i === count
                        ? getColorForPercentage((bpm - 40) / 200)
                        : "",
                  }}
                ></td>
            ))}

          {/* <td className="btn" style={{display:'block', opacity:'1', visibility:'visible', background:left?'':getColorForPercentage((bpm-40)/200)}}></td> */}
        </tr>
      </tbody>
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          alignItems: "flex-end",
        }}
      >
        <Typography style={{ fontFamily: "Fjalla One" }} variant="h1">
          {bpm}
        </Typography>
        <Typography
          style={{ fontFamily: "Fjalla One", color: "gray" }}
          variant="subtitle1"
        >
          BPM
        </Typography>
      </div>
      {/* <Metronome/> */}
      <PrettoSlider
        value={bpm}
        setValue={setBpm}
        color={getColorForPercentage((bpm - 40) / 200)}
      />
      <Fab onClick={handleChange}>
        {isPlay ? (
          <PauseIcon
            style={{
              fontSize: "48px",
              color: getColorForPercentage((bpm - 40) / 200),
            }}
            color="primary"
          />
        ) : (
          <PlayArrowIcon
            style={{
              fontSize: "48px",
              color: getColorForPercentage((bpm - 40) / 200),
            }}
            color="primary"
          />
        )}
      </Fab>
      <div>
        <IconButton
          onClick={() => setDot((o: number) => (o - 1 > -1 ? o - 1 : o))}
        >
          <RemoveCircleIcon
            fontSize="small"
            style={{ color: getColorForPercentage((bpm - 40) / 200) }}
          />
        </IconButton>
        <IconButton onClick={() => setDot((o: number) => o + 1)}>
          <AddCircleIcon
            fontSize="small"
            style={{ color: getColorForPercentage((bpm - 40) / 200) }}
          />
        </IconButton>
      </div>
    </div>
  );
}

export default HW5;

const percentColors = [
  { pct: 0.0, color: { r: 0x5a, g: 0x6b, b: 0xc0 } },
  { pct: 0.2, color: { r: 0x28, g: 0x7b, b: 0xc9 } },
  { pct: 0.5, color: { r: 0x14, g: 0xbb, b: 0xac } },
  { pct: 0.7, color: { r: 0xf6, g: 0x9f, b: 0x7 } },
  { pct: 1.0, color: { r: 0xff, g: 0, b: 0 } },
];

const getColorForPercentage = function (pct: number) {
  for (var i = 1; i < percentColors.length - 1; i++) {
    if (pct < percentColors[i].pct) {
      break;
    }
  }
  var lower = percentColors[i - 1];
  var upper = percentColors[i];
  var range = upper.pct - lower.pct;
  var rangePct = (pct - lower.pct) / range;
  var pctLower = 1 - rangePct;
  var pctUpper = rangePct;
  var color = {
    r: Math.floor(lower.color.r * pctLower + upper.color.r * pctUpper),
    g: Math.floor(lower.color.g * pctLower + upper.color.g * pctUpper),
    b: Math.floor(lower.color.b * pctLower + upper.color.b * pctUpper),
  };
  return "rgb(" + [color.r, color.g, color.b].join(",") + ")";
  // or output as hex if preferred
};
